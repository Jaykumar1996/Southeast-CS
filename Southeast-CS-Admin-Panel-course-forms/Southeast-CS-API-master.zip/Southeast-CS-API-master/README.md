# Southeast-CS-API
API that is used by both the Southeast CS mobile app and the Southeast CS Admin Panel. Check sionpixley/Southeast-CS for mobile app code. Check sionpixley/Southeast-CS-Admin-Panel for control panel code. This API uses Django.
